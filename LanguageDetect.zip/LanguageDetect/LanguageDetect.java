package com.qahumor.detectapi;

import java.io.BufferedReader;

import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URL;
import java.net.URLEncoder;


/*
 * author : qahumor
 * date : 20/Jan/2017
 * 
 */

public class LanguageDetect {

	private final String USER_AGENT = "Mozilla/5.0";
	private final String translateAPIURL = "http://www.transltr.org/api/translate?";
	private final String methodType = "GET";
	private final String requestValue = "USER_AGENT";

	// HTTP GET request
	public StringBuffer detectString(String text) throws Exception {

		String urlWithText = translateAPIURL + "text=" + URLEncoder.encode(text, "UTF-8") + "&to=en";

		System.out.println("EncodedURL Text : " + urlWithText);

		URL obj = new URL(urlWithText);
		HttpURLConnection con = (HttpURLConnection) obj.openConnection();

		con.setRequestMethod(methodType);

		// add request header
		con.setRequestProperty("User-Agent", requestValue);

		int responseCode = con.getResponseCode();

		BufferedReader in = new BufferedReader(new InputStreamReader(con.getInputStream()));
		String inputLine;
		StringBuffer response = new StringBuffer();

		while ((inputLine = in.readLine()) != null) {
			response.append(inputLine);
		}

		in.close();

		// print result
		// System.out.println(response.toString());
		// System.out.println(response.indexOf("from"));
		return response;

	}

}