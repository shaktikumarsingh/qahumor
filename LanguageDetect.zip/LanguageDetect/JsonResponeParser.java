package com.qahumor.detectapi;

import java.io.Serializable;

/*
 * author : qahumor
 * date : 20/Jan/2017
 * 
 */

public class JsonResponeParser implements Serializable {

	private String from;
	private String to;
	private String text;
	private String translationText;

	public String getFrom() {
		return from;
	}

	public void setFrom(String from) {
		this.from = from;
	}

	public String getTo() {
		return to;
	}

	public void setTo(String to) {
		this.to = to;
	}

	public String getText() {
		return text;
	}

	public void setText(String text) {
		this.text = text;
	}

	public String getTranslationText() {
		return translationText;
	}

	public void setTranslationText(String translationText) {
		this.translationText = translationText;
	}

}
