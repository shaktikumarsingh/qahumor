package com.qahumor.detectapi;

import com.google.gson.Gson;


/*
 * author : qahumor
 * date : 20/Jan/2017
 * 
 */

public class DemoTest {
	

	static Gson gson = new Gson();
	static JsonResponeParser name ;

	private final String USER_AGENT = "Mozilla/5.0";

	public static void main(String[] args) throws Exception {

		LanguageDetect http = new LanguageDetect();

		System.out.println("Passing String to Language Detect API ");
		StringBuffer response = http.detectString("Истекло время ожидания входа вследствие отсутствия активности.");
		
		name = gson.fromJson(response.toString(),JsonResponeParser.class);
		System.out.println("Detected language of String : " + name.getFrom());
	//	System.out.println(name.getTranslationText());

	}
	
	
}
